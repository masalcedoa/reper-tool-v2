# Cliente de carga: Postman + Web simple

## Postman
1. Importa `postman_uploads.json` en Postman.
2. Ajusta `baseUrl` a `http://<IP>:8000` (sin proxy) o `http://<IP>` si usas Caddy + este Caddyfile (porque la página llamará a `/api/...`). 
3. En **Subir CONSUMOS**, el `job_id` se guarda en variables automáticamente si la API lo devuelve.
4. Usa **Job Status** para monitorear el `job_id`.

## Web simple
- Copia `index.html` a la carpeta `web/` del servidor: `/opt/fraude-app/web/index.html`.
- Copia también `docker-compose.override.yml` y `Caddyfile.web` al directorio del proyecto.
- Levanta Caddy con el override:
  ```bash
  docker compose -f docker-compose.yml -f docker-compose.override.yml up -d caddy
  ```
- Abre `http://<IP>/` y deja el campo API base en **/api**.

## Notas
- Si vas a subir archivos muy grandes, considera usar DigitalOcean Spaces (S3) y presigned URLs.
- Para seguridad, añade autenticación (API keys/JWT) y CORS restringido en FastAPI.
